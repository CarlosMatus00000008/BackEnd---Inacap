from django.contrib import admin
from .models import Viaje


@admin.register(Viaje)
class ViajeAdmin(admin.ModelAdmin):
    list_display = ('destino', 'pais', 'fecha_inicio', 'duracion_dias', 'estado')
    list_filter = ('estado', 'pais')
    search_fields = ('destino', 'pais')
