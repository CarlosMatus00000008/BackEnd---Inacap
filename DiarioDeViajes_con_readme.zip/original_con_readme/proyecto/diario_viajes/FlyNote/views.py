from django.shortcuts import render
from .models import Viaje


def listar_viajes(request):
    viajes = Viaje.objects.all()
    return render(request, 'listar.html', {'viajes': viajes})
