from django.contrib import admin
from django.urls import path
from django.views.generic import RedirectView
from FlyNote import views

urlpatterns = [
    path('', RedirectView.as_view(url='viajes/', permanent=False)),
    path('admin/', admin.site.urls),
    path('viajes/', views.listar_viajes, name='listar_viajes'),
]
