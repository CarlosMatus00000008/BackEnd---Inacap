# Diario de Viajes — Guía para iniciar el proyecto

Este README explica todo lo necesario para levantar el proyecto Django
desde cero, paso a paso.

## Requisitos

- Python 3.10 o superior instalado
- Django 4.2

## 1. Crear y activar el entorno virtual

Un entorno virtual es una carpeta aislada donde se instalan las
librerías del proyecto, sin mezclarlas con otros proyectos de tu
computadora.

Desde la carpeta `proyecto` (donde está esta guía):

```powershell
# Crear el entorno virtual (solo la primera vez)
python -m venv venv

# Activar el entorno virtual (Windows / PowerShell)
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\venv\Scripts\Activate.ps1
```

```bash
# Activar el entorno virtual (Mac / Linux)
source venv/bin/activate
```

Si quedó activado correctamente, verás `(venv)` al inicio de la línea
de comandos.

## 2. Instalar Django

```bash
pip install Django==4.2
```

## 3. Entrar a la carpeta del proyecto Django

```bash
cd diario_viajes
```

Todos los comandos siguientes se ejecutan desde aquí (donde está el
archivo `manage.py`).

## 4. Crear las tablas en la base de datos

```bash
python manage.py makemigrations
python manage.py migrate
```

- `makemigrations` genera el plan de cambios a partir de `models.py`.
- `migrate` aplica ese plan sobre la base de datos (`db.sqlite3`).

## 5. Crear un usuario administrador

Necesario para poder entrar al panel de administración (`/admin/`).

```bash
python manage.py createsuperuser
```

Te pedirá un nombre de usuario, correo (opcional) y contraseña.

## 6. Iniciar el servidor

```bash
python manage.py runserver
```

Con el servidor corriendo, abre en el navegador:

- **Página principal (lista de viajes):** http://127.0.0.1:8000/viajes/
- **Panel de administración:** http://127.0.0.1:8000/admin/

## 7. Cargar datos de ejemplo

La página se ve mejor con datos reales. Puedes:

- Entrar a `/admin/`, iniciar sesión con el superusuario que creaste,
  y agregar viajes manualmente (botón "Add" junto a "Viajes"), o
- Si el proyecto trae un archivo de datos de ejemplo (`.json` dentro
  de `FlyNote/fixtures/`), cargarlo con:
  ```bash
  python manage.py loaddata nombre_del_archivo
  ```

## Estructura del proyecto (resumen)

```
proyecto/
└── diario_viajes/              ← carpeta del proyecto Django
    ├── manage.py                ← comando principal para correr Django
    ├── db.sqlite3                ← base de datos (se crea al hacer migrate)
    ├── diario_viajes/            ← configuración global
    │   ├── settings.py           ← configuración del proyecto
    │   └── urls.py                ← mapa de URLs del sitio
    └── FlyNote/                  ← la app con la funcionalidad de viajes
        ├── models.py              ← qué datos se guardan (modelo Viaje)
        ├── views.py               ← lógica que arma la página
        ├── admin.py               ← qué se ve en el panel de administración
        └── templates/listar.html ← el HTML que se muestra en el navegador
```

## Problemas comunes

| Problema | Causa probable | Solución |
|---|---|---|
| `python : no se reconoce como comando` | Python no está en el PATH | Reinstala Python marcando "Add to PATH", o usa `py` en vez de `python` |
| `No module named django` | El entorno virtual no está activado, o Django no se instaló | Repite el paso 1 (activar) y el paso 2 (instalar) |
| La página `/viajes/` aparece vacía | No hay datos cargados todavía | Ve al paso 7 y agrega viajes desde el admin |
| Error al hacer `migrate` | Cambiaste `models.py` pero no corriste `makemigrations` primero | Corre `python manage.py makemigrations` antes de `migrate` |
