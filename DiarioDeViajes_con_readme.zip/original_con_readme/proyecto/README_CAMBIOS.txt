CAMBIOS APLICADOS PARA CUMPLIR EL CASO 4 (Diario de Viajes)
==============================================================

Archivos modificados:
- FlyNote/models.py        -> Modelo Estudiante reemplazado por Viaje
                               (destino, pais, fecha_inicio, duracion_dias, estado, notas)
- FlyNote/views.py         -> listar_viajes() consulta Viaje.objects.all()
- FlyNote/admin.py         -> Viaje registrado en el admin
- diario_viajes/urls.py    -> Ruta cambiada de estudiantes/ a viajes/
- FlyNote/templates/listar.html -> Reemplazados los 3 viajes escritos a mano
                               por {% for viaje in viajes %} con {{ }} y {% if %}

Eliminados (para que Django los regenere limpios):
- FlyNote/migrations/0001_initial.py  (migraba el modelo Estudiante, ya no aplica)
- db.sqlite3                          (base de datos vieja con tabla Estudiante)

PASOS QUE FALTAN (correr tú, en orden, desde la carpeta diario_viajes):
1. Activar el venv (o usar el intérprete directo, ver el README.txt original)
2. python manage.py makemigrations
3. python manage.py migrate
4. python manage.py createsuperuser
   (crea tu propio usuario y contraseña — no reutilices los que estaban
   en el README.txt viejo, cámbialos)
5. python manage.py runserver
6. Entra a http://localhost:8000/admin/ y agrega 5+ viajes de ejemplo
7. Verifica en http://localhost:8000/viajes/ que se muestren con los
   colores correctos (gris=completado, azul=en_progreso, verde=planificado)

NOTA DE SEGURIDAD:
El README.txt original tenía una contraseña de superusuario en texto plano.
No la reutilices. Crea una nueva con createsuperuser.
