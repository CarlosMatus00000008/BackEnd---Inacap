Problema: PowerShell muestra "makemigrations : El término 'makemigrations' no se reconoce..."

Causa:
- "makemigrations" no es un comando del sistema por sí mismo. En Django debes ejecutarlo a través de `manage.py` usando Python.
- Además, si usas un virtualenv, debes activar el entorno o llamar al intérprete dentro del venv.

Solución (pasos en Windows, PowerShell):
1) Abrir PowerShell en la carpeta del proyecto que contiene `diario_viajes\manage.py`.
   - Por ejemplo: `cd C:\Users\alumnos09\Desktop\proyecto\diario_viajes`

2) Activar el virtualenv (opcional, pero recomendado):
   - Si quieres activar el venv en PowerShell (temporal para la sesión):
     ```powershell
     Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
     .\..\venv\Scripts\Activate.ps1
     ```
   - En CMD (si prefieres):
     ```cmd
     ..\venv\Scripts\activate.bat
     ```
   - Si no puedes activar por políticas de ejecución, puedes usar directamente el intérprete del venv (paso 4).

3) Asegurarse de que las dependencias estén instaladas (desde la carpeta `diario_viajes` o la raíz según tu flujo):
   ```powershell
   pip install -r ..\requirements.txt
   # o al menos instalar Django si falta:
   pip install Django
   ```

4) Ejecutar makemigrations correctamente (desde la carpeta que contiene `manage.py`):
   - Con el venv activado o con Python del sistema:
     ```powershell
     python manage.py makemigrations
     python manage.py migrate
     ```
   - Sin activar el venv, usando el ejecutable del venv directamente:
     ```powershell
     ..\venv\Scripts\python.exe manage.py makemigrations
     ..\venv\Scripts\python.exe manage.py migrate
     ```
   - Nota: NO ejecutar solo `makemigrations` en PowerShell — no es un comando independiente.

5) Si aparece "No changes detected", significa que no hay cambios en los modelos que requieran migraciones. Si hay errores de sintaxis en `FlyNote/models.py`, corrígelos y vuelve a ejecutar.

Consejos útiles:
- Ejecuta siempre los comandos desde la carpeta que contiene `manage.py` o indica la ruta completa a `manage.py`.
- Para ver qué Python se está usando: `python -V` o `..\venv\Scripts\python.exe -V`.

Resumen rápido de comandos (desde `C:\Users\alumnos09\Desktop\proyecto\diario_viajes`):
```powershell
# activar venv (PowerShell)
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
..\venv\Scripts\Activate.ps1







Si necesitas, puedo automatizar un script `run_migrate.ps1` que active el venv y ejecute las migraciones con seguridad.```python manage.py migratepython manage.py makemigrationsn# crear/migrar




superuser ;

user: alumnos09
password: hola123