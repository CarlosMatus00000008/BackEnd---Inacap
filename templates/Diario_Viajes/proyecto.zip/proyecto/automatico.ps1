$ErrorActionPreference = 'Stop'

$projectRoot = $PSScriptRoot
$venvPath = Join-Path $projectRoot 'venv'

Write-Host 'Comprobando si winget está disponible...'
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw 'winget no está instalado. Instálalo desde Microsoft Store o instala App Installer y vuelve a intentar.'
}

Write-Host 'Instalando o actualizando Python 3 a la última versión disponible...'
winget install --id Python.Python.3 --source winget --accept-source-agreements --accept-package-agreements -e

Write-Host 'Intentando actualizar Python si ya estaba instalado...'
winget upgrade --id Python.Python.3 --source winget --accept-source-agreements --accept-package-agreements -e

$pythonCommand = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCommand) {
    $pythonCommand = Get-Command py -ErrorAction SilentlyContinue
}

if (-not $pythonCommand) {
    throw 'Python no quedó disponible en PATH. Cierra y vuelve a abrir PowerShell para que el PATH se actualice.'
}

Write-Host 'Creando o reutilizando el entorno virtual...'
if (-not (Test-Path $venvPath)) {
    & python -m venv $venvPath
} else {
    Write-Host 'El entorno virtual ya existe.'
}

$venvPython = Join-Path $venvPath 'Scripts\python.exe'
if (-not (Test-Path $venvPython)) {
    throw "No se encontró el intérprete del entorno virtual: $venvPython"
}

Write-Host 'Actualizando pip...'
& $venvPython -m pip install --upgrade pip

Write-Host 'Instalando Django...'
& $venvPython -m pip install Django

Write-Host ''
Write-Host '¡Todo listo!'
Write-Host 'Activa el entorno con:'
Write-Host "  .\$($venvPath.Substring($projectRoot.Length + 1))\Scripts\Activate.ps1"
Write-Host 'O usa directamente el intérprete del venv para ejecutar Django.'

$ErrorActionPreference = 'Stop'

$projectRoot = $PSScriptRoot
$projectDir = Join-Path $projectRoot 'diario_viajes'
$venvActivate = Join-Path $projectRoot 'venv\Scripts\Activate.ps1'

if (-not (Test-Path $venvActivate)) {
    throw "No se encontró el entorno virtual en: $venvActivate"
}

if (-not (Test-Path $projectDir)) {
    throw "No se encontró la carpeta del proyecto: $projectDir"
}

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

& $venvActivate
Set-Location $projectDir

Write-Host "Ejecutando makemigrations..."
python manage.py makemigrations

Write-Host "Ejecutando migrate..."
python manage.py migrate

Write-Host "Proceso completado."
