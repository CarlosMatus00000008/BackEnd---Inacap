from django.shortcuts import render
from .models import Estudiante

def listar_estudiantes(request):
    estudiantes = Estudiante.objects.all()
    return render(request, 'listar.html',
        {'estudiantes': estudiantes})

# Create your views here.
