from django.db import models

class Estudiante(models.Model):
    nombre = models.CharField(
        max_length=100)
    matricula = models.CharField(
        max_length=20, unique=True)
    nota_final = models.FloatField()

    def __str__(self):
        return self.nombre


# Create your models here.
