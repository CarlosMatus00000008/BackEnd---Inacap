param(
    [string]$ProjectRoot,
    [string]$VenvName = "venv",
    [string]$RequirementsFile = "requirements.txt",
    [string]$ProjectName = "diario_viajes",
    [string]$AppName = "FlyNote",
    [switch]$SkipUpdateCheck,
    [switch]$SkipRunServer
)

$ErrorActionPreference = "Stop"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

function Write-Section {
    param([string]$Message)
    Write-Host ""
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host $Message -ForegroundColor Cyan
    Write-Host "==================================================" -ForegroundColor Cyan
}

function Ensure-LocalCodeSignature {
    $scriptPath = $PSCommandPath
    if (-not $scriptPath) {
        return
    }

    $certSubject = "CN=Local PowerShell Auto Script Signer"
    $cert = Get-ChildItem Cert:\CurrentUser\My -CodeSigningCert -ErrorAction SilentlyContinue |
        Where-Object { $_.Subject -eq $certSubject } |
        Select-Object -First 1

    if (-not $cert) {
        $cert = New-SelfSignedCertificate `
            -CertStoreLocation "Cert:\CurrentUser\My" `
            -Type CodeSigningCert `
            -Subject $certSubject `
            -FriendlyName "LocalPowerShellSigner" `
            -KeyUsage DigitalSignature `
            -KeySpec Signature
    }

    if ($cert) {
        try {
            Set-AuthenticodeSignature -FilePath $scriptPath -Certificate $cert -ErrorAction Stop
            Write-Host "Firma local aplicada a $scriptPath" -ForegroundColor Green
        } catch {
            Write-Warning "No se pudo firmar localmente el script: $($_.Exception.Message)"
        }
    }
}

function Ensure-Python {
    foreach ($candidate in @("py", "python")) {
        $command = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($command) {
            return $candidate
        }
    }

    Write-Host "Python no está instalado. Intentando instalarlo con winget..." -ForegroundColor Yellow
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        winget install --id Python.Python.3 -e --source winget
        if ($LASTEXITCODE -ne 0) {
            throw "No se pudo instalar Python."
        }
        return "py"
    }

    throw "No se encontró Python ni winget para instalarlo."
}

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    $candidateRoots = @(
        $PSScriptRoot,
        (Get-Location).Path,
        (Split-Path -Parent $PSScriptRoot)
    )

    foreach ($candidate in $candidateRoots) {
        if ($candidate -and (Test-Path $candidate)) {
            $candidateProject = Join-Path $candidate "diario_viajes"
            $candidateProjectAlt = Join-Path $candidate "diario_viaje"
            $candidateVenv = Join-Path $candidate "venv"
            $candidateManagePy = Join-Path $candidateProject "manage.py"
            $candidateManagePyAlt = Join-Path $candidateProjectAlt "manage.py"
            if ((Test-Path $candidateManagePy) -or (Test-Path $candidateManagePyAlt) -or (Test-Path $candidateVenv)) {
                $ProjectRoot = $candidate
                break
            }
        }
    }

    if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
        $ProjectRoot = $PSScriptRoot
    }
}

$resolvedRoot = (Resolve-Path $ProjectRoot).Path
$venvPath = Join-Path $resolvedRoot $VenvName
$activateScript = Join-Path $venvPath "Scripts\Activate.ps1"
$pythonCommand = Ensure-Python

Write-Section "Verificando entorno virtual"
if (-not (Test-Path $venvPath)) {
    Write-Host "No existe el entorno '$VenvName'. Creándolo..." -ForegroundColor Yellow
    & $pythonCommand -m venv $venvPath
    if ($LASTEXITCODE -ne 0) {
        throw "No se pudo crear el entorno virtual."
    }
} else {
    $venvPython = Join-Path $venvPath "Scripts\python.exe"
    $venvWorks = $false
    if (Test-Path $venvPython) {
        & $venvPython -c "import sys; print(sys.executable)" 2>$null
        $venvWorks = ($LASTEXITCODE -eq 0)
    }

    if (-not $venvWorks) {
        Write-Host "El entorno virtual no es válido o apunta a una ruta antigua. Recreándolo..." -ForegroundColor Yellow
        Remove-Item -Recurse -Force $venvPath
        & $pythonCommand -m venv $venvPath
        if ($LASTEXITCODE -ne 0) {
            throw "No se pudo recrear el entorno virtual."
        }
    } else {
        Write-Host "El entorno virtual ya existe y funciona correctamente. Se omite la creación." -ForegroundColor Green
    }
}

if (-not (Test-Path $activateScript)) {
    throw "No se encontró el script de activación: $activateScript"
}

Write-Host "Activando el entorno virtual..."
. $activateScript

$pythonExe = Join-Path $venvPath "Scripts\python.exe"
if (-not (Test-Path $pythonExe)) {
    throw "No se encontró Python dentro del entorno: $pythonExe"
}

Write-Section "Instalando y actualizando dependencias"
& $pythonExe -m pip install --upgrade pip setuptools wheel
$pipExitCode = $LASTEXITCODE
if ($pipExitCode -ne 0) {
    throw "No se pudo actualizar pip (código de salida $pipExitCode). Ejecuta '$pythonExe -m pip install --upgrade pip setuptools wheel' para ver el error completo."
}

& $pythonExe -m pip install --upgrade "django>=4.2,<5.0"
if ($LASTEXITCODE -ne 0) {
    throw "No se pudo instalar o actualizar Django 4.2 compatible con MariaDB 10.4."
}

& $pythonExe -m pip install --upgrade pymysql
if ($LASTEXITCODE -ne 0) {
    throw "No se pudo instalar o actualizar PyMySQL."
}

$projectPath = $null
foreach ($candidate in @("diario_viajes", "diario_viaje")) {
    $candidatePath = Join-Path $resolvedRoot $candidate
    if (Test-Path $candidatePath) {
        $projectPath = $candidatePath
        $ProjectName = $candidate
        break
    }
}

if (-not $projectPath) {
    Write-Section "Creando proyecto Django"
    Set-Location $resolvedRoot
    & $pythonExe -m django startproject $ProjectName
    if ($LASTEXITCODE -ne 0) {
        throw "No se pudo crear el proyecto Django."
    }
    $projectPath = Join-Path $resolvedRoot $ProjectName
}

Set-Location $projectPath
Write-Host "Directorio de trabajo: $projectPath" 

$managePy = Join-Path $projectPath "manage.py"
if (-not (Test-Path $managePy)) {
    throw "No se encontró manage.py en $projectPath."
}

$appPath = Join-Path $projectPath $AppName
if (-not (Test-Path $appPath)) {
    Write-Section "Creando aplicación $AppName"
    & $pythonExe $managePy startapp $AppName
    if ($LASTEXITCODE -ne 0) {
        throw "No se pudo crear la app $AppName."
    }
} else {
    Write-Host "La aplicación '$AppName' ya existe. Se omite la creación." -ForegroundColor Green
}

Write-Section "Comprobando dependencias"
$requirementsPath = Join-Path $resolvedRoot $RequirementsFile
if (Test-Path $requirementsPath) {
    Write-Host "Se encontró $RequirementsFile. Instalando dependencias..."
    & $pythonExe -m pip install -r $requirementsPath
    if ($LASTEXITCODE -ne 0) {
        throw "La instalación de dependencias falló."
    }
} else {
    Write-Host "No existe $RequirementsFile en $resolvedRoot. Se omite la instalación desde archivo." -ForegroundColor DarkYellow
}

if (-not $SkipUpdateCheck) {
    Write-Section "Verificando actualizaciones disponibles"
    & $pythonExe -m pip list --outdated --format=columns
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "La comprobación de actualizaciones terminó con código $LASTEXITCODE."
    }
} else {
    Write-Host "Se omitió la comprobación de actualizaciones por parámetro." 
}

Write-Section "Generando migraciones"
& $pythonExe $managePy makemigrations
if ($LASTEXITCODE -ne 0) {
    throw "No se pudieron generar las migraciones."
}

Write-Section "Aplicando migraciones"
& $pythonExe $managePy migrate
if ($LASTEXITCODE -ne 0) {
    throw "No se pudieron aplicar las migraciones."
}

if (-not $SkipRunServer) {
    Write-Section "Iniciando Django"
    Write-Host "Ejecutando: python manage.py runserver"
    & $pythonExe $managePy runserver
} else {
    Write-Host "Se omitió la ejecución de runserver por parámetro."
}

Ensure-LocalCodeSignature

Write-Host ""
Write-Host "Entorno virtual activo y proyecto listo." -ForegroundColor Green
Write-Host "Ruta del entorno: $venvPath" 
Write-Host "Ruta del proyecto: $projectPath" 

# SIG # Begin signature block
# MIIFqQYJKoZIhvcNAQcCoIIFmjCCBZYCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUHui4pEr1eJZsYURt9FFT8hRX
# bkigggMwMIIDLDCCAhSgAwIBAgIQF2zdcpiiX6tOZ9vQobvRIzANBgkqhkiG9w0B
# AQUFADAuMSwwKgYDVQQDDCNMb2NhbCBQb3dlclNoZWxsIEF1dG8gU2NyaXB0IFNp
# Z25lcjAeFw0yNjA5MDEwNDQzMjNaFw0yNzA5MDEwNTAzMjNaMC4xLDAqBgNVBAMM
# I0xvY2FsIFBvd2VyU2hlbGwgQXV0byBTY3JpcHQgU2lnbmVyMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEA9nORQD5sL/HnAei3gnr0AbYeJT5gFpX8Nn+A
# GAiL/xniYYArbymXcKLemXDSCC8F9ffWfJPWmb1tg5bVUyvVQv8yDm89h8Xk/tcV
# PtruRle5OLnYI1pqTLirA7SrJsP75jm4Dm5YnDmh4BJ7S7Ti6k+3iDPdqESOl+Z8
# 2LX6CTD3ydaT67bcZdZmgM0IYBO7GzRC9FHyvP6eRNMBXnst0EdA3HZJ09LSmY1P
# /C65xUwJdJolVfaMnmK9ymC16J4xuGB48TdVi19yxkfK0lXD4ToeK79ATK8xk+0X
# 0zgw6k89NsNHfQKMnp8Kg14BOK85MkEb84uANL7Z9+xnZaZ93QIDAQABo0YwRDAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFA1P
# p+TiT5iW6y9GqbOxA5p5MZnmMA0GCSqGSIb3DQEBBQUAA4IBAQCZ1kQsWD9O5yAQ
# 3CdveEmmX/xK1k05YbEdycXIP7uo1BVvn3TBPQJ4jW6JRddOO50QWCsD48bzOhb8
# s5W7jROKqWZ5K74Iy/1dxEtMeiqYvaQ8pRW6GWgrZWl72rMP8l4xCRJItMt/CGeE
# u261/8wWRlPf0QVujRkmRaI/9WRTSt5AbOBsYrV4T8kpMUKHdeZZ0xSK7ylFRJ+3
# EBBfyDLMOrlOZ+7QOQedNfHn8gMGflFW9i1DMHH4Kya7Uj36vhQLA4kbkRtvalwJ
# 7OkfbzvzbmtLKyjyS8krBpQJTRB/7tEbuIKvJHrZjC8p6NxmHpKrrPQrSQnJ1VDP
# Xo4OxT7rMYIB4zCCAd8CAQEwQjAuMSwwKgYDVQQDDCNMb2NhbCBQb3dlclNoZWxs
# IEF1dG8gU2NyaXB0IFNpZ25lcgIQF2zdcpiiX6tOZ9vQobvRIzAJBgUrDgMCGgUA
# oHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0B
# CQQxFgQUzjeigdVgZ50o/PSNjr5Z30qHznUwDQYJKoZIhvcNAQEBBQAEggEAIwL1
# i6qdWRerdQ4OL7P77xla5R3AEdq8fOx7zWPu0cSOvvlYzK104LPIFbbSCwOaxwpW
# PVAxv2dBm1gKeETyZKoD2gNCqBpb9WElKfqPFhnL/ggVOTABjE0nk3aq5dVEpJKC
# jS3/b5y6+cTObn7Ltl0wCQYmFWEq0AA6mq9Szzu/aFDPTMv7w0uMXazq5/EtM5zV
# lC6P7Mhcckv+7Shic8k1d2cxPLyG0QGsjEuv1KUZOw1tMQs/AudBBjDTQw4DYS/2
# BroM4aezAms+nh4N1YmrCgQZfoZu499hqnyNF3+UEuO6ql+ebeTUQxQABriUPGaS
# H3M1gLBc7Iasnet6cw==
# SIG # End signature block
