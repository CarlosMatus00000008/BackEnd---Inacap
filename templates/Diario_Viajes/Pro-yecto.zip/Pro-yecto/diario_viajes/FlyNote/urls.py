from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.listar_viajes, name='listar'),
    path('admin/', views.admin_viajes, name='admin_viajes'),
    path('admin/usuario/<int:usuario_id>/', views.admin_viajes_usuario, name='admin_viajes_usuario'),
    path('crear/', views.crear_viaje, name='crear_viaje'),
    path('editar/<int:id>/', views.editar_viaje, name='editar_viaje'),
    path('eliminar/<int:id>/', views.eliminar_viaje, name='eliminar_viaje'),
    path('login/', views.login_view, name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('registro/', views.registro, name='registro'),
]