from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Viaje


class RegistroForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']


class ViajeForm(forms.ModelForm):
    class Meta:
        model = Viaje
        fields = ['destino', 'pais', 'fecha_inicio', 'fecha_fin', 'estado', 'notas', 'es_publico']
        widgets = {
            'fecha_inicio': forms.DateInput(attrs={'type': 'date'}),
            'fecha_fin': forms.DateInput(attrs={'type': 'date'}),
            'notas': forms.Textarea(attrs={'rows': 4}),
        }