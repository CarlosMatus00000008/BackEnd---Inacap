from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from django.shortcuts import redirect
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from .models import Viaje
from .forms import RegistroForm, ViajeForm


def home(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect('admin_viajes')
        else:
            return redirect('listar')
    else:
        return redirect('login')


@login_required
def listar_viajes(request):
    if request.user.is_staff:
        return redirect('admin_viajes')
    request.session['ultimo_usuario_id'] = request.user.id
    viajes = Viaje.objects.filter(usuario=request.user).exclude(fecha_inicio__isnull=True).order_by('-fecha_inicio')
    return render(request, 'usuario.html', {'viajes': viajes})


@login_required
def crear_viaje(request):
    if request.user.is_staff:
        return redirect('admin_viajes')
    if request.method == 'POST':
        form = ViajeForm(request.POST)
        if form.is_valid():
            viaje = form.save(commit=False)
            viaje.usuario = request.user
            viaje.save()
            return redirect('listar')
    else:
        form = ViajeForm()
    return render(request, 'crearViaje.html', {'form': form})


@login_required
def editar_viaje(request, id):
    viaje = get_object_or_404(Viaje, id=id)
    if viaje.usuario != request.user and not request.user.is_staff:
        return redirect('listar')

    if request.method == 'POST':
        form = ViajeForm(request.POST, instance=viaje)
        if form.is_valid():
            form.save()
            if request.user.is_staff:
                return redirect('admin_viajes_usuario', usuario_id=viaje.usuario.id)
            return redirect('listar')
    else:
        form = ViajeForm(instance=viaje)

    return render(request, 'editarViaje.html', {'form': form, 'viaje': viaje})


@login_required
def eliminar_viaje(request, id):
    viaje = get_object_or_404(Viaje, id=id)
    if viaje.usuario != request.user and not request.user.is_staff:
        return redirect('listar')
    usuario_id = viaje.usuario.id
    viaje.delete()
    if request.user.is_staff:
        return redirect('admin_viajes_usuario', usuario_id=usuario_id)
    return redirect('listar')


def registro(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            usuario = form.save()
            login(request, usuario)
            # Guardar ID del usuario en sesión
            request.session['ultimo_usuario_id'] = usuario.id
            return redirect('listar')
    else:
        form = RegistroForm()
    return render(request, 'resgistro.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            usuario = form.get_user()
            login(request, usuario)
            # Guardar ID del usuario en sesión
            request.session['ultimo_usuario_id'] = usuario.id
            return redirect('listar')
    else:
        form = AuthenticationForm()
    return render(request, 'iniciarSesion.html', {'form': form})


@login_required
def admin_viajes(request):
    if not request.user.is_staff:
        return redirect('listar')
    usuarios = User.objects.all().order_by('username')
    return render(request, 'superAdmin.html', {'usuarios': usuarios})


@login_required
def admin_viajes_usuario(request, usuario_id):
    if not request.user.is_staff:
        return redirect('listar')
    usuario = get_object_or_404(User, id=usuario_id)
    viajes = Viaje.objects.filter(usuario=usuario).exclude(fecha_inicio__isnull=True).order_by('-fecha_inicio')
    return render(request, 'superAdmin.html', {'usuario': usuario, 'viajes': viajes})