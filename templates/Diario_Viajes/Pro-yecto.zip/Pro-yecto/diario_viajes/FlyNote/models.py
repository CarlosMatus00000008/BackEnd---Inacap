from django.db import models
from django.contrib.auth.models import User

class Viaje(models.Model):
    ESTADO = [
        ("Completado", "Completado"),
        ("Planificado", "Planificado"),
        ("EnProgreso", "En Progreso"),
    ]
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='viajes')
    destino = models.CharField(max_length=100)
    pais = models.CharField(max_length=50)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField(null=True, blank=True)
    estado = models.CharField(max_length=20, choices=ESTADO)
    notas = models.TextField(blank=True)
    es_publico = models.BooleanField(default=False)

    class Meta:
        ordering = ['-fecha_inicio']

    def __str__(self):
        return f"{self.destino} - {self.pais}"