from django.contrib import admin
from .models import Viaje

@admin.register(Viaje)
class ViajeAdmin(admin.ModelAdmin):
    list_display = ('pais', 'fecha_inicio', 'fecha_fin', 'estado', 'notas', 'es_publico')
    list_filter = ('estado', 'es_publico', 'pais')
    search_fields = ('pais',)